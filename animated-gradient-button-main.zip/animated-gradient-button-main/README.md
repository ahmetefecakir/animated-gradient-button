# Animated Gradient Button
## [Visit our site](https://empati.org)
### Animated Gradient Button

- Animated Gradient Button Using HTML & CSS
- With beautiful animated colors.
- And a gradient shadow when doing the hover effect.

> Follow our instagram account to see more content like this. [Empati](https://www.instagram.com/empatiweb)

![preview img](/preview.png)
